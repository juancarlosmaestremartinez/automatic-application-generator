package ua.autoapp.gvalumni

import android.os.Bundle
import android.view.*
import android.widget.Button
import android.widget.RadioGroup
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ua.autoapp.gvalumni.entity.ItemResponse
import kotlin.reflect.full.memberProperties

/**
 * A simple [Fragment] subclass.
 * Use the [DialogFragmentSelectId.newInstance] factory method to
 * create an instance of this fragment.
 */
class DialogFragmentSelectId : DialogFragment() {

    private var radio_group: RadioGroup? = null
    private var save_button: Button? = null
    private var checkbox_saved: com.google.android.material.checkbox.MaterialCheckBox? = null
    private var list_ids: MutableList<String> = mutableListOf<String>()
    private var listener: OnDialogFragmentSelectIdListener? = null
    private var adapter_workplace_list: IdIRecyclerViewAdapter? = null
    var onSelectIdClick: ((String)-> Unit)?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val attributes = ItemResponse::class.memberProperties

        for (attribute in attributes) {
            list_ids.add(attribute.name)
        }

        try {
            val check_fragment = requireActivity().supportFragmentManager.findFragmentByTag("dialog")
            if(check_fragment is OnDialogFragmentSelectIdListener) {
                listener = check_fragment
            }
        } catch (e: ClassCastException) {
            throw ClassCastException("Calling fragment must implement Callback interface")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_dialog_select_id, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        radio_group = view.findViewById(R.id.radio_group_center_list_check_fragment)
        save_button = view.findViewById(R.id.button_save_dialog_select_workplaces_check_fragment)
        val recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view_workplace_list_radio_button)

        if(recyclerView is RecyclerView){
            adapter_workplace_list = IdIRecyclerViewAdapter(radio_group, list_ids.toTypedArray())
            val linear_layout = LinearLayoutManager(context)
            recyclerView.layoutManager = linear_layout
            recyclerView.adapter = adapter_workplace_list
        }
        save_button!!.setOnClickListener {
            if(list_ids != null && list_ids!!.size > 0) {
                if(IdIRecyclerViewAdapter.radio_button_id_selected >= 0 && IdIRecyclerViewAdapter.radio_button_id_selected < list_ids!!.size) {
                    val idItem = list_ids!![IdIRecyclerViewAdapter.radio_button_id_selected]
                    this.dismiss()
                    onSelectIdClick?.invoke(idItem)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()

        val window = dialog!!.window
        val lp = WindowManager.LayoutParams()
        lp.gravity = Gravity.TOP or Gravity.END
        val width = (resources.displayMetrics.widthPixels * 0.9).toInt()
        val height = (resources.displayMetrics.heightPixels * 0.6).toInt()
        window!!.setLayout(width,height)
    }


    interface OnDialogFragmentSelectIdListener {
        fun onSelectId(idItem: String, isCheckRememberActive: Boolean?)
    }

}