package ua.autoapp.gvalumni

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.recyclerview.widget.RecyclerView

class IdIRecyclerViewAdapter(private val radioGroup: RadioGroup?, private val list_ids: Array<String>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object{
        var radio_button_id_selected = -1
    }
    private var radio_group: RadioGroup? = null
    private var radio_button_selected: RadioButton? = null


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        radio_group = radioGroup
        val item = LayoutInflater.from(parent.context).inflate(R.layout.layout_radio_button_item,parent,false)
        return ViewHolder(item)
    }

    override fun getItemCount(): Int = list_ids.size

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val radio_button = itemView.findViewById(R.id.radio_button_center_list_check_fragment) as? RadioButton

        fun bind(idItem: String?){
            if(idItem != null && idItem != null){
                radio_button?.text = idItem
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder_item = holder as ViewHolder
        val item = list_ids[position]
        holder.itemView.setOnClickListener {
            if(radio_group != null){
                if(radio_button_selected == null){
                    holder_item.radio_button?.isChecked = true
                    radio_button_selected = holder_item.radio_button
                }
                else{
                    radio_button_selected?.isChecked = false
                    holder_item.radio_button?.isChecked = true
                    radio_button_selected = holder_item.radio_button
                }
                radio_button_id_selected = position
            }
        }
        holder_item.bind(item)
    }

}