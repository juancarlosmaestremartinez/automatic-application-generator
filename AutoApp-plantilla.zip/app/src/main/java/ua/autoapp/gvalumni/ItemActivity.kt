package ua.autoapp.gvalumni

import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ua.autoapp.gvalumni.entity.ItemResponse
import kotlin.reflect.full.memberProperties

class ItemActivity : AppCompatActivity() {

    lateinit var itemAdapter: ItemAdapter
    lateinit var recyclerView: RecyclerView
    lateinit var titleTV: TextView
    lateinit var itemResponse: ItemResponse

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_centro)

        if(MainActivity.itemResponse != null){
            itemResponse = MainActivity.itemResponse!!
        }

        // Set the top action bar
        val actionBar = supportActionBar
        actionBar!!.show()
        actionBar.setLogo(R.mipmap.ic_launcher)
        actionBar.setDisplayUseLogoEnabled(true)
        actionBar.setDisplayShowHomeEnabled(true)
        actionBar.setDisplayHomeAsUpEnabled(true)
        actionBar.setBackgroundDrawable(ColorDrawable(Color.parseColor("#151791")))
        actionBar.title = getString(R.string.app_name)
        recyclerView = findViewById(R.id.recycler_view)
        titleTV = findViewById(R.id.nombre)
        // Get the Intent that started this activity and extract the string


        val attributes = ItemResponse::class.memberProperties
        for (attribute in attributes) {
            if(attribute.name == MainActivity.principalAttribute){
                val valor = attribute.getter.call(MainActivity.itemResponse)
                titleTV.text = valor.toString()
            }
        }

        val listPairTitleValue = mutableListOf<Pair<String, String>>()
        for (attribute in attributes) {
            val value = attribute.getter.call(MainActivity.itemResponse).toString()
            val title = attribute.name
            if(value != null && value!= "null" && value.isNotEmpty() && value.isNotBlank() &&
                title != null && title!= "null" && title.isNotEmpty() && title.isNotBlank()){
                listPairTitleValue.add(Pair(title,value))
            }
        }

        itemAdapter = ItemAdapter(listPairTitleValue)
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(this)
        itemAdapter.onItemClick = { title: String, value: String ->
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clipData = ClipData.newPlainText("text", value)
            clipboard.setPrimaryClip(clipData)
            Toast.makeText(this, "$title copiado en el portapapeles",Toast.LENGTH_SHORT).show()
        }
        recyclerView.adapter = itemAdapter

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return false
    }
}
