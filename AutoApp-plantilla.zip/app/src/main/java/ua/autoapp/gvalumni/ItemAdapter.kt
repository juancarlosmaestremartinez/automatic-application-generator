package ua.autoapp.gvalumni

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ItemAdapter (val items: List<Pair<String,String>>) : RecyclerView.Adapter<ItemAdapter.ViewHolder>() {

    var onItemClick: ((String,String)-> Unit)?= null

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var titleTV: TextView
        var valueTV: TextView

        init {
            // Define click listener for the ViewHolder's View.
            titleTV = view.findViewById(R.id.titleTV)
            valueTV = view.findViewById(R.id.valueTV)
        }
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        holder.titleTV.text = item.first
        holder.valueTV.text = item.second
        holder.itemView.setOnClickListener {
            onItemClick?.invoke(item.first,item.second)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return ViewHolder(layoutInflater.inflate(R.layout.item_recycler_view, parent, false))
    }

    override fun getItemCount(): Int {
        return items.size
    }


}
