package ua.autoapp.gvalumni

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.widget.TextView.OnEditorActionListener
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isGone
import androidx.core.view.isVisible
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import ua.autoapp.gvalumni.entity.ItemResponse
import ua.autoapp.gvalumni.entity.ResultResponse
import ua.autoapp.gvalumni.entity.URL
import java.util.concurrent.TimeUnit
import kotlin.reflect.full.memberProperties


class MainActivity : AppCompatActivity(){

    var searchView: EditText? = null
    var iv_search: ImageView? = null
    var closeButton: ImageButton? = null
    var listView: ListView? = null
    var arrayAdapter: ItemAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Set the top action bar
        val actionBar = supportActionBar
        actionBar!!.show()
        actionBar.setLogo(R.mipmap.ic_launcher)
        actionBar.setDisplayUseLogoEnabled(true)
        actionBar.setDisplayShowHomeEnabled(true)
        //actionBar.
        //actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setBackgroundDrawable(ColorDrawable(Color.parseColor("#151791")))
        actionBar.title = getString(R.string.app_name)
        closeButton = findViewById(R.id.imageButtonCancel)
        listView = findViewById(R.id.lista_centros)
        listView?.isGone = true
        closeButton?.setOnClickListener {
            searchView?.text?.clear()
            it.isGone = true
            hideKeyboard()
            itemList = originItemList
            buildAdapter()
        }
        iv_search = findViewById(R.id.iv_search)

        val sharedPref = getPreferences(Context.MODE_PRIVATE)
        if(sharedPref != null) {
            val attributes = ItemResponse::class.memberProperties
            val idAttribute = sharedPref.getString(getString(R.string.principal_attribute), getString(R.string.default_principal_attribute))
            var isAttribute = false
            for (attribute in attributes) {
                if(attribute.name == idAttribute){
                    isAttribute = true
                }
            }
            if(idAttribute != null && (idAttribute == getString(R.string.default_principal_attribute) || idAttribute.isEmpty() || idAttribute.isEmpty() || !isAttribute) ){
                val dialogFragmentSelectId = DialogFragmentSelectId()
                dialogFragmentSelectId.onSelectIdClick = {
                    principalAttribute = it
                    val sharedPref = getPreferences(Context.MODE_PRIVATE)
                    if(sharedPref != null) {
                        with(sharedPref.edit()) {
                            putString(getString(R.string.principal_attribute), it)
                            apply()
                        }
                    }
                    arrayAdapter?.notifyDataSetChanged()
                    listView?.isGone = false
                }
                dialogFragmentSelectId.show(supportFragmentManager, "dialog")
            }
            else {
                if(idAttribute != null) {
                    principalAttribute = idAttribute
                    arrayAdapter?.notifyDataSetChanged()
                    listView?.isGone = false
                }
            }
        }

        searchView = findViewById(R.id.et_search_bar)
        searchView?.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {
                closeButton?.isGone = false
            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {
            }
        })
        searchView?.setOnEditorActionListener(OnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                closeButton?.isGone = false
                closeButton?.isVisible = true
                itemList = checkAllFields(itemList,searchView?.text.toString()).toMutableList()
                buildAdapter()
                hideKeyboard()
                return@OnEditorActionListener true
            }
            false
        })

        iv_search?.setOnClickListener {
            searchView?.isFocusableInTouchMode = true
            searchView?.requestFocus()

            val inputMethodManager: InputMethodManager = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.toggleSoftInputFromWindow(this.currentFocus?.applicationWindowToken, InputMethodManager.SHOW_FORCED, 0)

        }
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (this.currentFocus != null) {
            imm.hideSoftInputFromWindow(this.currentFocus!!.windowToken, 0)
        }

        // Progress bar
        try {
            //getActivity().requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
            setProgressBarIndeterminateVisibility(true)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Progress bar
        setProgressBarIndeterminateVisibility(false)
        val pb = findViewById<View>(R.id.pbHeaderProgress) as ProgressBar
        pb.visibility = View.VISIBLE
        executeCall()
    }


    private fun executeCall() {
        val url = java.net.URL(URL.url)
        val baseUrl: String = url.protocol + "://" + url.host
        val methodUrl = URL.url.replace(baseUrl,"")
        CoroutineScope(Dispatchers.IO).launch {
            val call = getRetrofit().create(APIService::class.java).getItems(methodUrl)
            try {
                val items = call.body()

                runOnUiThread {
                    if (call.isSuccessful) {
                        doPostExecute(items)
                    } else {
                        showErrorDialog()
                    }
                    //hideKeyboard()
                }
            } catch (e: Exception){
                showErrorDialog()
            }
        }
    }

    private fun doPostExecute(result: ResultResponse?) {
        if (result != null) {
            try {
                for(item in result.results){
                    itemList
                    itemList.add(item)
                    //Log.i("CallAPI", centro.getNombre());
                }
                originItemList = itemList
                val attributes = ItemResponse::class.memberProperties
                if(attributes.isNotEmpty() && principalAttribute != getString(R.string.default_principal_attribute)){
                    buildAdapter()
                }

                // Progress bar
                setProgressBarIndeterminateVisibility(false)
                val pb = findViewById<View>(R.id.pbHeaderProgress) as ProgressBar
                pb.visibility = View.INVISIBLE
                Log.i("CallAPI", itemList.size.toString() + "")
            } catch (e: Exception) {
                Log.i("CallAPI", e.message!!)
            }
        }
    }

    private fun getRetrofit(): Retrofit {
        val httpClient = OkHttpClient.Builder()
            .callTimeout(2, TimeUnit.MINUTES)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
        val url = java.net.URL(URL.url)
        val baseUrl: String = url.protocol + "://" + url.host
        val builder: Retrofit.Builder = Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())

        builder.client(httpClient.build())
        return builder.build()
    }


    private fun showErrorDialog() {
        Toast.makeText(this, "Ha ocurrido un error", Toast.LENGTH_SHORT).show()
    }

    inner class ItemAdapter(private val mContext: Context, list: List<ItemResponse>) :
        ArrayAdapter<ItemResponse>(mContext, 0, list), Filterable {
        private var itemList = listOf<ItemResponse>()

        init {
            itemList = list
        }

        inner class ItemHolder {
            var nombre: TextView? = null
        }

        override fun getCount(): Int {
            return itemList.size
        }

        override fun getItem(position: Int): ItemResponse {
            return itemList[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            var convertView = convertView
            val holder: ItemHolder
            if (convertView == null) {
                convertView =
                    LayoutInflater.from(mContext).inflate(R.layout.list_item, parent, false)
                holder = ItemHolder()
                holder.nombre = convertView.findViewById<View>(R.id.textView_nombre) as TextView
                //holder.age=(TextView) convertView.findViewById(R.id.txtAge);
                convertView.tag = holder
            } else {
                holder = convertView.tag as ItemHolder
            }

            val attributes = ItemResponse::class.memberProperties
            for (attribute in attributes) {
                if(attribute.name == principalAttribute){
                    val valor = attribute.getter.call(itemList[position])
                    holder.nombre!!.text = valor.toString()
                }
            }

            //holder.age.setText(String.valueOf(employeeArrayList.get(position).getAge()));
            return convertView!!
        }
    }

    companion object {
        const val POSITION = "position"
        var itemResponse: ItemResponse? = null
        var principalAttribute = ""
        var itemList = mutableListOf<ItemResponse>()
        var originItemList = mutableListOf<ItemResponse>()
    }

    private fun checkAllFields(itemList: List<ItemResponse>, sequence: String): List<ItemResponse> {
        var res = mutableListOf<ItemResponse>()
        if(sequence.isEmpty().or(sequence.isBlank())){
            res = originItemList.toMutableList()
            MainActivity.itemList = originItemList
        }
        else {
            val attributes = ItemResponse::class.memberProperties
            for (i in itemList.indices) {
                for (attribute in attributes) {
                    val valor = attribute.getter.call(itemList[i])
                    if (valor != null && valor is String && valor.contains(
                            sequence,
                            ignoreCase = true
                        ) && !res.contains(itemList[i])
                    ) {
                        res.add(itemList[i])
                    }
                }
            }
        }
        return res
    }

    private fun buildAdapter(){
        arrayAdapter = ItemAdapter(this@MainActivity, itemList)
        listView!!.adapter = arrayAdapter
        listView!!.onItemClickListener =
            AdapterView.OnItemClickListener { parent, view, position, id ->
                itemResponse = itemList[position]
                val intent = Intent(this@MainActivity, ItemActivity::class.java)
                startActivity(intent)
                //Toast.makeText(MainActivity.this, "click " + parent.getItemAtPosition(position).toString(), Toast.LENGTH_LONG).show();
            }
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(this.currentFocus?.windowToken, 0)
    }

}
