package com.example.autoapp.entity



data class ItemResponse (placeholder)