package ua.autoapp.gvalumni.entity



data class ItemResponse (placeholder)