package ua.autoapp.gvalumni.entity


import com.example.autoapp.entity.ItemResponse
import com.google.gson.annotations.SerializedName

data class ResultResponse (

    @SerializedName("results"       ) var results       : ArrayList<ItemResponse> = arrayListOf(),
    @SerializedName("limit"         ) var limit         : Int?               = null,
    @SerializedName("offset"        ) var offset        : Int?               = null,
    @SerializedName("visualisation" ) var visualisation : Boolean?           = null,
    @SerializedName("fileSize"      ) var fileSize      : String?            = null,
    @SerializedName("resultsSize"   ) var resultsSize   : String?            = null

)