package ua.autoapp.gvalumni.entity

class URL {
    companion object{
        val url = "placeholder"
    }
}